package com.example.guesssongs;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Collections;
import java.util.List;

public class HistoryActivity extends AppCompatActivity {
    private Button returnto;
    private TextView highestScoreTextView;
    private TextView scoresListTextView;

    private DatabaseHelper databaseHelper;
    private int currentUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        // Initialize the DatabaseHelper
        databaseHelper = new DatabaseHelper(this);

        // Get the current user ID (ensure this ID is passed correctly)
        currentUserId = getIntent().getIntExtra("USER_ID", -1);

        // Initialize Views
        findViews();

        // Display user history data
        displayUserHistory();

        // Set up return button functionality
        returnto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();  // Return to the previous activity
            }
        });
    }

    private void findViews() {
        returnto = findViewById(R.id.BacktoMain);
        highestScoreTextView = findViewById(R.id.highestScoreTextView);
        scoresListTextView = findViewById(R.id.scoresListTextView);
    }

    private void displayUserHistory() {
        // Get the highest score for the user
        int highestScore = databaseHelper.getHighestScore(currentUserId);

        // Check if the highestScore is valid (e.g., handle -1 or no score found)
        if (highestScore != -1) {
            highestScoreTextView.setText("历史最高成绩: " + highestScore);
        } else {
            highestScoreTextView.setText("历史最高成绩: 无");
        }

        // Get all scores ordered by completion time
        List<ScoreEntry> scoreEntries = databaseHelper.getAllScores(currentUserId);

        // Sort the list by completion time (assuming ScoreEntry has a completionTime field)
        if (scoreEntries != null && !scoreEntries.isEmpty()) {
            Collections.sort(scoreEntries, (entry1, entry2) -> entry1.getCompletionTime().compareTo(entry2.getCompletionTime()));

            // Prepare the string to display the score entries
            StringBuilder scoresDisplay = new StringBuilder();
            for (ScoreEntry entry : scoreEntries) {
                scoresDisplay.append("得分: ").append(entry.getScore())
                        .append(", 完成时间: ").append(entry.getCompletionTime())
                        .append(", 得分率: ").append(entry.getScoreRate()).append("\n");
            }

            // Display the scores in the TextView
            scoresListTextView.setText(scoresDisplay.toString());
        } else {
            scoresListTextView.setText("历史成绩: 无");
        }
    }
}