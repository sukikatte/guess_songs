package com.example.guesssongs;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class EndlessActivity extends AppCompatActivity{
    private Button returnto;
    private TextView usersBest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manual);
        findViews();
        updateUsersBestDisplay();
        returnto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 返回到登录活动
                finish(); // 或者可以使用 Intent
            }
        });
    }
    private void findViews() {
        returnto = findViewById(R.id.BacktoMain);
        usersBest = findViewById(R.id.usersBest);
    }
    private void updateUsersBestDisplay() {
        ScoreManager scoreManager = new ScoreManager(this);
        int bestScore = scoreManager.getBestScore();
        usersBest.setText("Users' Best: " + bestScore);
    }
}
