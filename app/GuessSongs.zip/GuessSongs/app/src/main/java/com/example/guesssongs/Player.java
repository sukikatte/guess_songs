package com.example.guesssongs;

public class Player {
    private String username;
    private int score;
    private boolean answered;
    private String answer;

    public Player(String username) {
        this.username = username;
        this.score = 0;
        this.answered = false;
        this.answer = "";
    }

    // No-argument constructor is required by Firebase
    public Player() {}

    public Player(String username, int score, boolean answered, String answer) {
        this.username = username;
        this.score = score;
        this.answered = answered;
        this.answer = answer;
    }


    // Getter and Setter methods
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public boolean hasAnswered() {
        return answered;
    }

    public void setAnswered(boolean answered) {
        this.answered = answered;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}
