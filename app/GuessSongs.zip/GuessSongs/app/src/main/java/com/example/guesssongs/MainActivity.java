package com.example.guesssongs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.competitiveMode.CompetitiveActivity;
import com.example.guesssongs.competitiveMode.RoomStateActivity;
import com.example.guesssongs.log.LoginActivity;

public class MainActivity extends AppCompatActivity {
    private Button logout,start_game,hardmode,manual,history,competitive;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // 确保这是您的主活动布局文件
        findViews();
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 返回到登录活动
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
        start_game.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 启动注册活动
                Intent intent = new Intent(MainActivity.this, GameActivity.class);
                startActivity(intent);
            }
        });
        hardmode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "Efforts are under development", Toast.LENGTH_SHORT).show();
            }
        });
        manual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 启动注册活动
                Intent intent = new Intent(MainActivity.this, ManualActivity.class);
                startActivity(intent);
            }
        });
        history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 启动注册活动
                Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
                startActivity(intent);
            }
        });
        competitive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 启动注册活动
                Intent intent = new Intent(MainActivity.this, RoomStateActivity.class);
                startActivity(intent);
            }
        });
    }
    private void findViews() {
        logout = findViewById(R.id.Logout);
        start_game = findViewById(R.id.start_game);
        hardmode = findViewById(R.id.hardmode);
        manual = findViewById(R.id.manual);
        history = findViewById(R.id.history);
        competitive = findViewById(R.id.mc);
    }
}
