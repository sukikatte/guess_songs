package com.example.guesssongs.competitiveMode;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.R;

public class ResultActivity extends AppCompatActivity {

    private TextView tvResults;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tvResults = findViewById(R.id.tvResults);

        String[] playerNicknames = getIntent().getStringArrayExtra("playerNicknames");
        int[] scores = getIntent().getIntArrayExtra("scores");

        if (playerNicknames != null && scores != null) {
            displayResults(playerNicknames, scores);
        }
    }

    private void displayResults(String[] nicknames, int[] scores) {
        StringBuilder results = new StringBuilder();
        for (int i = 0; i < nicknames.length; i++) {
            results.append(nicknames[i]).append(": ").append(scores[i]).append("\n");
        }
        tvResults.setText(results.toString());
    }
}