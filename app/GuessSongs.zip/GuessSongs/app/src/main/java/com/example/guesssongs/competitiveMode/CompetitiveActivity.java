/*package com.example.guesssongs.competitiveMode;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.Player;
import com.example.guesssongs.R;
import com.example.guesssongs.Songs;
import com.example.guesssongs.SummaryActivity;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CompetitiveActivity extends AppCompatActivity {
    private DatabaseReference roomRef; // Firebase reference to the room
    private String roomName; // Current room name
    private String nickname; // Current player's nickname

    private Button optionA, optionB, optionC, optionD;
    private TextView timeCountingTextView, questionText, scoreTotal;
    private final Handler handler = new Handler();
    private MediaPlayer mediaPlayer;
    private int seconds = 0;
    private int score = 0;
    private int completedQuestions = 0;
    private int currentQuestion = 1; // Current question number
    private TextView progressText;

    private List<Player> players; // List to store players
    private int correctAnswerCount = 0; // Correct answers count
    private String correctAnswer; // Current correct answer
    private int timeLimit = 31; // Time limit for each question
    private boolean isQuestionActive = false; // Is the question active?
    private Runnable timerRunnable; // Timer for countdown

    private List<Songs> songs = new ArrayList<>(); // List of songs
    private Random random;
    private Songs currentSong;

    // TextViews for displaying players' names and scores
    private TextView player1Name, player2Name, player3Name;
    private TextView player1Score, player2Score, player3Score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_competitive);

        roomName = getIntent().getStringExtra("roomName"); // Get room name
        nickname = getIntent().getStringExtra("nickname"); // Get player's nickname
        roomRef = FirebaseDatabase.getInstance().getReference("rooms").child(roomName); // Get Firebase reference for room

        // Initialize players list
        players = new ArrayList<>();
        players.add(new Player());
        players.add(new Player());
        players.add(new Player());
        // Initialize game state
        completedQuestions = 0;
        score = 0;
        seconds = 0;
        Log.d("CompetitiveActivity", "onCreate called");

        findViews();
        random = new Random();
        initializeSongs();
        loadNextQuestion();
        setupOptionButtons();
        listenForPlayerUpdates(); // Listen for player score updates in Firebase
    }

    private void listenForPlayerUpdates() {
        roomRef.child("players").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // Loop through players and update their score
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Player player = snapshot.getValue(Player.class);
                    if (player != null) {
                        updatePlayerScore(player);
                    }
                }
                updateScoreDisplay(); // Update score display after getting data
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle database error
                Log.e("Firebase", "Error listening for player updates", databaseError.toException());
            }
        });
    }

    private void findViews() {
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        optionD = findViewById(R.id.optionD);
        timeCountingTextView = findViewById(R.id.time_couting);
        questionText = findViewById(R.id.question_text);
        progressText = findViewById(R.id.progress_text);
        scoreTotal = findViewById(R.id.score_total);

        // Initialize TextViews for displaying players' names and scores
        player1Name = findViewById(R.id.player1_name);
        player2Name = findViewById(R.id.player2_name);
        player3Name = findViewById(R.id.player3_name);
        player1Score = findViewById(R.id.player1_score);
        player2Score = findViewById(R.id.player2_score);
        player3Score = findViewById(R.id.player3_score);
    }

    private void initializeSongs() {
        songs.add(new Songs(R.raw.song1, "宝贝", "张悬"));
        songs.add(new Songs(R.raw.song2, "艳火", "张悬"));
        songs.add(new Songs(R.raw.song3, "猎户星座", "朴树"));
        songs.add(new Songs(R.raw.song4, "平凡之路", "朴树"));
        songs.add(new Songs(R.raw.song5, "Mystery of Love", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song6, "Visions of Gideon", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song7, "The Only Thing", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song8, "台北流浪指南", "伤心欲绝"));
        songs.add(new Songs(R.raw.song9, "月光散落的地方", "伤心欲绝"));
        songs.add(new Songs(R.raw.song10, "Lemon", "米津玄師"));
    }

    @SuppressLint("SetTextI18n")
    private void loadNextQuestion() {
        if (completedQuestions >= 10) {
            navigateToSummary(); // Navigate to summary activity
            return;
        }
        isQuestionActive = true;
        correctAnswerCount = 0; // Reset correct answer count
        startTimer(); // Start timer
        updateProgress();

        currentSong = songs.get(random.nextInt(songs.size())); // Select a random song
        playSong(currentSong.getResourceId());

        boolean askForTitle = random.nextBoolean();
        if (askForTitle) {
            questionText.setText("What is the title of this song?");
            replaceRandomOption(currentSong.getTitle());
        } else {
            questionText.setText("What is the singer of this song?");
            replaceRandomOption(currentSong.getSinger());
        }

        // Reset player state
        for (Player player : players) {
            player.setAnswered(false);
            player.setAnswer("");
        }
    }

    private void replaceRandomOption(String correctAnswer) {
        Button[] options = {optionA, optionB, optionC, optionD};
        int randomIndex = random.nextInt(options.length);
        options[randomIndex].setText(correctAnswer);

        List<String> wrongOptions = new ArrayList<>();
        for (Songs song : songs) {
            if (!song.getTitle().equals(correctAnswer) && !song.getSinger().equals(correctAnswer)) {
                wrongOptions.add(song.getTitle());
                wrongOptions.add(song.getSinger());
            }
        }

        Collections.shuffle(wrongOptions);

        for (int i = 0; i < options.length; i++) {
            if (i != randomIndex) {
                if (wrongOptions.isEmpty()) {
                    options[i].setText("选项 " + (char) ('A' + i));
                } else {
                    options[i].setText(wrongOptions.remove(0));
                }
            }
        }
    }

    private void playSong(int songResId) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(this, songResId);
        if (mediaPlayer == null) {
            Log.e("CompetitiveActivity", "Failed to load song: " + songResId);
            return;
        }
        mediaPlayer.start();
    }

    @SuppressLint("SetTextI18n")
    private void startTimer() {
        long startTime = SystemClock.elapsedRealtime();
        long endTime = startTime + timeLimit * 1000;

        // Remove any previous callbacks to prevent multiple instances of the timer
        handler.removeCallbacksAndMessages(null);

        timerRunnable = new Runnable() {
            @Override
            public void run() {
                long currentTime = SystemClock.elapsedRealtime();
                long remainingTime = endTime - currentTime;

                if (remainingTime > 0) {
                    seconds = (int) (remainingTime / 1000);
                    timeCountingTextView.setText(String.valueOf(seconds));
                    handler.postDelayed(this, 1000);
                } else {
                    isQuestionActive = false;
                    Toast.makeText(CompetitiveActivity.this, "时间到，自动跳转到下一题！", Toast.LENGTH_SHORT).show();
                    loadNextQuestion();
                }
            }
        };

        handler.postDelayed(timerRunnable, 1000); // Start the timer after 1 second
    }

    private void setupOptionButtons() {
        optionA.setOnClickListener(v -> checkAnswer(optionA.getText().toString()));
        optionB.setOnClickListener(v -> checkAnswer(optionB.getText().toString()));
        optionC.setOnClickListener(v -> checkAnswer(optionC.getText().toString()));
        optionD.setOnClickListener(v -> checkAnswer(optionD.getText().toString()));
    }

    private void checkAnswer(String selectedAnswer) {
        boolean isTitleQuestion = questionText.getText().toString().contains("title");
        String correctAnswer = isTitleQuestion ? currentSong.getTitle() : currentSong.getSinger();

        // Check if player has already answered
        Player currentPlayer = players.get(0); // Assuming player[0] for simplicity
        if (currentPlayer.hasAnswered()) {
            Toast.makeText(this, "你已经答过了！", Toast.LENGTH_SHORT).show();
            return;
        }
        currentPlayer.setAnswered(true);
        currentPlayer.setAnswer(selectedAnswer);

        if (selectedAnswer.equals(correctAnswer)) {
            correctAnswerCount++;
            completedQuestions++;
            Log.d("GameActivity", "Completed Questions: " + completedQuestions);
            int points = 0;
            switch (correctAnswerCount) {
                case 1:
                    points = 10;
                    break;
                case 2:
                    points = 7;
                    break;
                case 3:
                    points = 5;
                    break;
            }
            currentPlayer.setScore(currentPlayer.getScore() + points);
            Toast.makeText(this, currentPlayer.getUsername() + " 答对了，得 " + points + " 分！", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, currentPlayer.getUsername() + " 答错了，不得分！", Toast.LENGTH_SHORT).show();
        }

        updatePlayerScore(currentPlayer);

        if (completedQuestions == 10) {
            navigateToSummary();
        } else if (correctAnswerCount == players.size() || seconds <= 0) {
            isQuestionActive = false;
            loadNextQuestion();
        }
    }

    private void navigateToSummary() {
        Intent intent = new Intent(CompetitiveActivity.this, SummaryActivity.class);
        startActivity(intent);
        finish();
    }

    private void updatePlayerScore(Player player) {
        roomRef.child("players").child(player.getUsername()).child("score").setValue(player.getScore());
        roomRef.child("players").child(player.getUsername()).child("answered").setValue(player.hasAnswered());
    }

    private void updateScoreDisplay() {
        if (scoreTotal == null) {
            Log.e("CompetitiveActivity", "scoreTotal TextView is null");
            return;
        }

        StringBuilder scoreDisplay = new StringBuilder("得分情况：\n");
        for (Player player : players) {
            scoreDisplay.append(player.getUsername()).append(": ").append(player.getScore()).append("\n");
        }
        scoreTotal.setText(scoreDisplay.toString());

        // Update each player's individual score
        player1Score.setText("Player 1: " + players.get(0).getScore());
        player2Score.setText("Player 2: " + players.get(1).getScore());
        player3Score.setText("Player 3: " + players.get(2).getScore());
    }

    private void updateProgress() {
        progressText.setText(currentQuestion + "/" + "10");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}

 */
/*
package com.example.guesssongs.competitiveMode;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.Player;
import com.example.guesssongs.R;
import com.example.guesssongs.Songs;
import com.example.guesssongs.SummaryActivity;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import android.media.MediaPlayer;
import android.util.Log;
import java.util.Collections;

public class CompetitiveActivity extends AppCompatActivity {
    private DatabaseReference roomRef;
    private String roomName;
    private String nickname;

    private Button optionA, optionB, optionC, optionD;
    private TextView timeCountingTextView, questionText, scoreTotal;
    private TextView player1Name, player2Name, player3Name;
    private TextView player1Score, player2Score, player3Score;
    private final Handler handler = new Handler();
    private MediaPlayer mediaPlayer;
    private int seconds = 0;
    private int score = 0;
    private int completedQuestions = 0;
    private int currentQuestion = 1;
    private TextView progressText;

    private List<Player> players;
    private int correctAnswerCount = 0;
    private String correctAnswer;
    private int timeLimit = 31;
    private boolean isQuestionActive = false;
    private Runnable timerRunnable;
    private List<Songs> songs = new ArrayList<>();
    private Random random;
    private Songs currentSong;

    private Player currentPlayer; // Track the current player answering

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_competitive);

        findViews(); // Move this line up here

        roomName = getIntent().getStringExtra("roomName");

        // Retrieve player nicknames from the intent
        String[] playerNicknames = getIntent().getStringArrayExtra("nickname");

        // Ensure that the roomName and nicknames are not null
        if (roomName == null || roomName.isEmpty()) {
            Log.e("CompetitiveActivity", "Room name is null or empty!");
            Toast.makeText(this, "Room name is invalid", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity
            return;
        }

        if (playerNicknames == null || playerNicknames.length != 3) {
            Log.e("CompetitiveActivity", "Player nicknames are invalid!");
            Toast.makeText(this, "Player nicknames are invalid", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity
            return;
        }

        // Set player nicknames to the TextViews
        player1Name.setText("玩家1: " + playerNicknames[0]);
        player2Name.setText("玩家2: " + playerNicknames[1]);
        player3Name.setText("玩家3: " + playerNicknames[2]);

        // Initialize room reference and other components
        roomRef = FirebaseDatabase.getInstance().getReference("rooms").child(roomName);

        players = new ArrayList<>();
        players.add(new Player(playerNicknames[0]));
        players.add(new Player(playerNicknames[1]));
        players.add(new Player(playerNicknames[2]));

        random = new Random();
        initializeSongs();
        loadNextQuestion();
        setupOptionButtons();
        listenForPlayerUpdates();
    }

    private void listenForPlayerUpdates() {
        roomRef.child("players").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Player player = snapshot.getValue(Player.class);
                    if (player != null) {
                        updatePlayerScore(player);
                    }
                }
                updateScoreDisplay();
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("Firebase", "Error listening for player updates", databaseError.toException());
            }
        });
    }

    private void findViews() {
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        optionD = findViewById(R.id.optionD);
        timeCountingTextView = findViewById(R.id.time_couting);
        questionText = findViewById(R.id.question_text);
        progressText = findViewById(R.id.progress_text);
        scoreTotal = findViewById(R.id.score_total);

        player1Name = findViewById(R.id.player1_name);
        player2Name = findViewById(R.id.player2_name);
        player3Name = findViewById(R.id.player3_name);
        player1Score = findViewById(R.id.player1_score);
        player2Score = findViewById(R.id.player2_score);
        player3Score = findViewById(R.id.player3_score);
    }

    private void initializeSongs() {
        songs.add(new Songs(R.raw.song1, "宝贝", "张悬"));
        songs.add(new Songs(R.raw.song2, "艳火", "张悬"));
        songs.add(new Songs(R.raw.song3, "猎户星座", "朴树"));
        songs.add(new Songs(R.raw.song4, "平凡之路", "朴树"));
        songs.add(new Songs(R.raw.song5, "Mystery of Love", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song6, "Visions of Gideon", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song7, "The Only Thing", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song8, "台北流浪指南", "伤心欲绝"));
        songs.add(new Songs(R.raw.song9, "月光散落的地方", "伤心欲绝"));
        songs.add(new Songs(R.raw.song10, "Lemon", "米津玄師"));
    }

    @SuppressLint("SetTextI18n")
    private void loadNextQuestion() {
        if (completedQuestions >= 10) {
            navigateToSummary();
            return;
        }

        isQuestionActive = true;
        correctAnswerCount = 0;
        startTimer();
        updateProgress();

        currentSong = songs.get(random.nextInt(songs.size()));
        playSong(currentSong.getResourceId());

        boolean askForTitle = random.nextBoolean();
        if (askForTitle) {
            questionText.setText("What is the title of this song?");
            replaceRandomOption(currentSong.getTitle());
        } else {
            questionText.setText("What is the singer of this song?");
            replaceRandomOption(currentSong.getSinger());
        }

        for (Player player : players) {
            player.setAnswered(false);
            player.setAnswer("");
        }

        // Choose the first player to answer (this can be rotated or chosen randomly)
        currentPlayer = players.get(0); // For example, Player 1 starts
    }

    private void replaceRandomOption(String correctAnswer) {
        Button[] options = {optionA, optionB, optionC, optionD};
        int randomIndex = random.nextInt(options.length);
        options[randomIndex].setText(correctAnswer);

        List<String> wrongOptions = new ArrayList<>();
        for (Songs song : songs) {
            if (!song.getTitle().equals(correctAnswer) && !song.getSinger().equals(correctAnswer)) {
                wrongOptions.add(song.getTitle());
                wrongOptions.add(song.getSinger());
            }
        }

        Collections.shuffle(wrongOptions);

        for (int i = 0; i < options.length; i++) {
            if (i != randomIndex) {
                if (wrongOptions.isEmpty()) {
                    options[i].setText("Option " + (char) ('A' + i));
                } else {
                    options[i].setText(wrongOptions.remove(0));
                }
            }
        }
    }

    private void playSong(int songResId) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(this, songResId);
        if (mediaPlayer == null) {
            Log.e("CompetitiveActivity", "Failed to load song: " + songResId);
            return;
        }
        mediaPlayer.start();
    }

    @SuppressLint("SetTextI18n")
    private void startTimer() {
        long startTime = SystemClock.elapsedRealtime();
        long endTime = startTime + timeLimit * 1000;

        handler.removeCallbacksAndMessages(null);

        timerRunnable = new Runnable() {
            @Override
            public void run() {
                long currentTime = SystemClock.elapsedRealtime();
                long remainingTime = endTime - currentTime;

                if (remainingTime > 0) {
                    seconds = (int) (remainingTime / 1000);
                    timeCountingTextView.setText(String.valueOf(seconds));
                    handler.postDelayed(this, 1000);
                } else {
                    isQuestionActive = false;
                    Toast.makeText(CompetitiveActivity.this, "Time's up, moving to the next question!", Toast.LENGTH_SHORT).show();
                    loadNextQuestion();
                }
            }
        };

        handler.postDelayed(timerRunnable, 1000);
    }

    private void setupOptionButtons() {
        optionA.setOnClickListener(v -> checkAnswer(optionA.getText().toString()));
        optionB.setOnClickListener(v -> checkAnswer(optionB.getText().toString()));
        optionC.setOnClickListener(v -> checkAnswer(optionC.getText().toString()));
        optionD.setOnClickListener(v -> checkAnswer(optionD.getText().toString()));
    }

    private void checkAnswer(String selectedAnswer) {
        boolean isTitleQuestion = questionText.getText().toString().contains("title");
        String correctAnswer = isTitleQuestion ? currentSong.getTitle() : currentSong.getSinger();

        if (currentPlayer.hasAnswered()) {
            Toast.makeText(this, "You have already answered!", Toast.LENGTH_SHORT).show();
            return;
        }
        currentPlayer.setAnswered(true);
        currentPlayer.setAnswer(selectedAnswer);

        if (selectedAnswer.equals(correctAnswer)) {
            correctAnswerCount++;
            completedQuestions++;
            Log.d("GameActivity", "Completed Questions: " + completedQuestions);
            int points = 0;
            switch (correctAnswerCount) {
                case 1: points = 10; break;
                case 2: points = 7; break;
                case 3: points = 5; break;
            }
            currentPlayer.setScore(currentPlayer.getScore() + points);
            Toast.makeText(this, currentPlayer.getUsername() + " got it right! + " + points + " points!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, currentPlayer.getUsername() + " got it wrong! No points.", Toast.LENGTH_SHORT).show();
        }

        updatePlayerScore(currentPlayer);

        if (completedQuestions == 10) {
            navigateToSummary();
        } else if (correctAnswerCount == players.size() || seconds <= 0) {
            isQuestionActive = false;
            loadNextQuestion();
        }
    }

    private void navigateToSummary() {
        Intent intent = new Intent(CompetitiveActivity.this, SummaryActivity.class);
        startActivity(intent);
        finish();
    }

    private void updatePlayerScore(Player player) {
        roomRef.child("players").child(player.getUsername()).child("score").setValue(player.getScore());
        roomRef.child("players").child(player.getUsername()).child("answered").setValue(player.hasAnswered());
    }

    private void updateScoreDisplay() {
        StringBuilder scoreDisplay = new StringBuilder("Scores:\n");
        for (Player player : players) {
            scoreDisplay.append(player.getUsername()).append(": ").append(player.getScore()).append("\n");
        }
        scoreTotal.setText(scoreDisplay.toString());

        player1Score.setText("Player 1: " + players.get(0).getScore());
        player2Score.setText("Player 2: " + players.get(1).getScore());
        player3Score.setText("Player 3: " + players.get(2).getScore());
    }

    private void updateProgress() {
        progressText.setText("Question " + currentQuestion + "/10");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}

 */
package com.example.guesssongs.competitiveMode;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.R;
import com.example.guesssongs.Songs;
import com.example.guesssongs.SummaryActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

public class CompetitiveActivity extends AppCompatActivity {
    private TextView tvPlayer1, tvPlayer2, tvPlayer3, questionText, timeCountingTextView, scorePlayer1, scorePlayer2, scorePlayer3, progressText;
    private Button optionA, optionB, optionC, optionD;
    private int seconds = 30;
    private final Handler handler = new Handler();
    private Random random;
    private Songs currentSong;
    private int currentQuestion = 1;
    private List<String> playersAnswers;
    private List<Integer> playersScores;
    private final List<Songs> songs = new ArrayList<>();
    private Socket socket;
    private DatabaseReference scoresRef, gameRef;

    private void initializeSongs() {
        songs.add(new Songs(R.raw.song1, "宝贝", "张悬"));
        songs.add(new Songs(R.raw.song2, "艳火", "张悬"));
        songs.add(new Songs(R.raw.song3, "猎户星座", "朴树"));
        songs.add(new Songs(R.raw.song4, "平凡之路", "朴树"));
        songs.add(new Songs(R.raw.song5, "Mystery of Love", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song6, "Visions of Gideon", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song7, "The Only Thing", "Sufjan Stevens"));

        Log.d("CompetitiveActivity", "Songs initialized: " + songs.size());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_competitive);

        findViews();
        random = new Random();
        initializeSongs();

        // Initialize Firebase references
        scoresRef = FirebaseDatabase.getInstance().getReference("scores");
        gameRef = FirebaseDatabase.getInstance().getReference("game");

        String[] playerNicknames = getIntent().getStringArrayExtra("nickname");
        if (playerNicknames != null && playerNicknames.length == 3) {
            tvPlayer1.setText("玩家1: " + playerNicknames[0]);
            tvPlayer2.setText("玩家2: " + playerNicknames[1]);
            tvPlayer3.setText("玩家3: " + playerNicknames[2]);
        }

        playersAnswers = new ArrayList<>(Collections.nCopies(3, ""));
        playersScores = new ArrayList<>(Collections.nCopies(3, 0));

        try {
            socket = IO.socket("http://192.168.3.19:3000"); // Ensure this is the server IP
            socket.connect();
        } catch (Exception e) {
            e.printStackTrace();
        }

        socket.on("start-next-question", onStartNextQuestion);
        socket.on("update-scores", onUpdateScores);
        socket.on("player-joined", onPlayerJoined);
        socket.on("game-started", onGameStarted);

        // Listen for the game start signal from Firebase
        gameRef.child("status").setValue("waiting");  // Set initial game status
        listenForGameStart();  // Start listening for the game to start

        // Other setup
        setupOptionButtons();
        startTimer();
    }

    private void findViews() {
        tvPlayer1 = findViewById(R.id.tvPlayer1);
        tvPlayer2 = findViewById(R.id.tvPlayer2);
        tvPlayer3 = findViewById(R.id.tvPlayer3);
        questionText = findViewById(R.id.question_text);
        timeCountingTextView = findViewById(R.id.time_couting);
        scorePlayer1 = findViewById(R.id.score_player1);
        scorePlayer2 = findViewById(R.id.score_player2);
        scorePlayer3 = findViewById(R.id.score_player3);
        progressText = findViewById(R.id.progress_text);
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        optionD = findViewById(R.id.optionD);
    }

    private void listenForGameStart() {
        gameRef.child("status").setValue("waiting");  // Set initial game status
        Log.d("CompetitiveActivity", "Game status set to waiting");

// Listening for game start
        gameRef.child("status").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if ("started".equals(dataSnapshot.getValue())) {
                    Log.d("CompetitiveActivity", "Game started, loading next question.");
                    loadNextQuestion();  // Load the first question
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                Log.e("CompetitiveActivity", "Error listening for game status", databaseError.toException());
            }
        });


    }

    private void loadNextQuestion() {
        if (currentQuestion > 10) {
            navigateToSummary();
            return;
        }

        playersAnswers = new ArrayList<>(Collections.nCopies(3, ""));
        if (songs.isEmpty()) {
            Toast.makeText(this, "歌曲列表为空，请确保歌曲数据已加载", Toast.LENGTH_SHORT).show();
            return;
        }

        currentSong = songs.get(random.nextInt(songs.size()));
        if (currentSong == null) {
            Toast.makeText(this, "当前歌曲为空，请检查歌曲数据", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean askForTitle = random.nextBoolean();
        String question = askForTitle ? "What is the title of this song?" : "What is the singer of this song?";
        questionText.setText(question);

        Log.d("CompetitiveActivity", "Current Song: " + currentSong.getTitle() + " by " + currentSong.getSinger());

        replaceRandomOptions(askForTitle ? currentSong.getTitle() : currentSong.getSinger());
        seconds = 30;
        timeCountingTextView.setText("Time: " + seconds);

        progressText.setText("Question: " + currentQuestion + "/10");

        handler.removeCallbacksAndMessages(null);
        startTimer();

        gameRef.child("currentQuestion").setValue(currentQuestion);
        gameRef.child("currentSongTitle").setValue(currentSong.getTitle());
        gameRef.child("currentSongSinger").setValue(currentSong.getSinger());
    }


    private void replaceRandomOptions(String correctAnswer) {
        Button[] options = {optionA, optionB, optionC, optionD};
        int randomIndex = random.nextInt(options.length);

        options[randomIndex].setText(correctAnswer);
        Log.d("CompetitiveActivity", "Correct answer placed at option: " + randomIndex);

        List<String> wrongAnswers = getWrongAnswers(correctAnswer);
        Collections.shuffle(wrongAnswers);
        for (int i = 0; i < options.length; i++) {
            if (i != randomIndex) {
                options[i].setText(wrongAnswers.remove(0));
                Log.d("CompetitiveActivity", "Wrong answer placed at option: " + i);
            }
        }
    }


    // 获取题库中的错误答案
    private List<String> getWrongAnswers(String correctAnswer) {
        List<String> wrongAnswers = new ArrayList<>();
        for (Songs song : songs) {
            // 确保错误答案不等于正确答案
            if (!song.getTitle().equals(correctAnswer) && !song.getSinger().equals(correctAnswer)) {
                wrongAnswers.add(song.getTitle());
                wrongAnswers.add(song.getSinger());
            }
        }
        return wrongAnswers;
    }

    private void startTimer() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (seconds > 0) {
                    seconds--;
                    timeCountingTextView.setText("Time: " + seconds);
                    handler.postDelayed(this, 1000);
                } else {
                    moveToNextQuestion();
                }
            }
        }, 1000);
    }

    private void moveToNextQuestion() {
        currentQuestion++;
        loadNextQuestion();
    }

    private void setupOptionButtons() {
        optionA.setOnClickListener(v -> checkAnswer(optionA.getText().toString(), 0));
        optionB.setOnClickListener(v -> checkAnswer(optionB.getText().toString(), 1));
        optionC.setOnClickListener(v -> checkAnswer(optionC.getText().toString(), 2));
        optionD.setOnClickListener(v -> checkAnswer(optionD.getText().toString(), 3));
    }

    private void updateScoresInFirebase(int playerIndex, int score) {
        // Update score in Firebase
        scoresRef.child("player" + (playerIndex + 1)).setValue(score);
    }

    private void checkAnswer(String selectedAnswer, int playerIndex) {
        // 确保玩家没有重复回答
        if (!playersAnswers.get(playerIndex).equals("")) {
            Toast.makeText(this, "You've already answered!", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean isTitleQuestion = questionText.getText().toString().contains("title");
        String correctAnswer = isTitleQuestion ? currentSong.getTitle() : currentSong.getSinger();

        if (selectedAnswer.equals(correctAnswer)) {
            playersScores.set(playerIndex, playersScores.get(playerIndex) + 10); // 加10分
            Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Incorrect!", Toast.LENGTH_SHORT).show();
        }

        playersAnswers.set(playerIndex, selectedAnswer);

        // 更新Firebase中的得分
        updateScoresInFirebase(playerIndex, playersScores.get(playerIndex));

        // 如果所有玩家都回答完或时间到，进入下一题
        if (!playersAnswers.contains("") || seconds == 0) {
            moveToNextQuestion();
        }

        updateScoreDisplay();
    }

    private void updateScoreDisplay() {
        scorePlayer1.setText("Player 1 Score: " + playersScores.get(0));
        scorePlayer2.setText("Player 2 Score: " + playersScores.get(1));
        scorePlayer3.setText("Player 3 Score: " + playersScores.get(2));
    }

    private void navigateToSummary() {
        Intent intent = new Intent(CompetitiveActivity.this, SummaryActivity.class);
        intent.putExtra("player1_score", playersScores.get(0));
        intent.putExtra("player2_score", playersScores.get(1));
        intent.putExtra("player3_score", playersScores.get(2));
        startActivity(intent);
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (socket != null) {
            socket.disconnect();
        }
    }



    // Listeners for socket events
    private final Emitter.Listener onStartNextQuestion = args -> runOnUiThread(this::loadNextQuestion);
    private final Emitter.Listener onUpdateScores = args -> runOnUiThread(() -> {
        int playerIndex = (int) args[0];
        int updatedScore = (int) args[1];
        playersScores.set(playerIndex, updatedScore);
        updateScoreDisplay();
    });

    private final Emitter.Listener onPlayerJoined = args -> runOnUiThread(() -> {
        // Handle player joining, assign correct index, etc.
    });

    private final Emitter.Listener onGameStarted = args -> runOnUiThread(this::loadNextQuestion);
}
