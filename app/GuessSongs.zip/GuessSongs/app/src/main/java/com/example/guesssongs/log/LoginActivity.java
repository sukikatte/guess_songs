package com.example.guesssongs.log;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.MainActivity;
import com.example.guesssongs.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends AppCompatActivity {
    private Button login, register;
    private EditText username, password;
    private FirebaseDatabase mDatabase;
    private DatabaseReference mDatabaseRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log); // Make sure this is your login layout

        mDatabase = FirebaseDatabase.getInstance();
        mDatabaseRef = mDatabase.getReference("user");  // Reference to users data

        Log.d("Firebase", "Firebase connected: " + (mDatabase != null));

        findViews();

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();

                // Check user credentials in Firebase
                mDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        boolean isAuthenticated = false;

                        // Loop through all users
                        for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                            User userFromDb = userSnapshot.getValue(User.class);

                            // If username and password match
                            if (userFromDb != null && userFromDb.getUsername().equals(user) && userFromDb.getPassword().equals(pass)) {
                                isAuthenticated = true;
                                break;
                            }
                        }

                        // Handle authentication result
                        if (isAuthenticated) {

                            Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);  // Proceed to main activity
                        } else {
                            Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(LoginActivity.this, "Error occurred. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start RegisterActivity for user registration
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();

                // Check user credentials in Firebase
                mDatabaseRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        boolean isAuthenticated = false;

                        // Loop through all users
                        for (DataSnapshot userSnapshot : dataSnapshot.getChildren()) {
                            User userFromDb = userSnapshot.getValue(User.class);

                            // If username and password match
                            if (userFromDb != null && userFromDb.getUsername().equals(user) && userFromDb.getPassword().equals(pass)) {
                                isAuthenticated = true;
                                break;
                            }
                        }

                        // Handle authentication result
                        if (isAuthenticated) {
                            Toast.makeText(LoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            startActivity(intent);  // Proceed to main activity
                        } else {
                            Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                        Toast.makeText(LoginActivity.this, "Error occurred. Try again later.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private void findViews() {
        login = findViewById(R.id.login);
        register = findViewById(R.id.register);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
    }
}


/*public class LoginActivity extends AppCompatActivity {
    private Button login, register;
    private EditText username, password;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log); // 确保这是你的登录布局文件

        dbHelper = new DatabaseHelper(this);
        findViews();

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 启动注册活动
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();
                // 检查用户是否存在
                if (dbHelper.isUserExists(user, pass)) {
                    Toast.makeText(LoginActivity.this, "The user logged in successfully", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                    startActivity(intent); // 这里可以转到下一个活动
                } else {
                    Toast.makeText(LoginActivity.this, "The user does not exist", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void findViews() {
        login = findViewById(R.id.login);
        register = findViewById(R.id.register);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
    }
}

 */
