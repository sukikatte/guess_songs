package com.example.guesssongs;

public class ScoreEntry {
    private int score;
    private String completionTime;
    private double scoreRate;

    public ScoreEntry(int score, String completionTime, double scoreRate) {
        this.score = score;
        this.completionTime = completionTime;
        this.scoreRate = scoreRate;
    }

    public int getScore() {
        return score;
    }

    public String getCompletionTime() {
        return completionTime;
    }

    public double getScoreRate() {
        return scoreRate;
    }
}
