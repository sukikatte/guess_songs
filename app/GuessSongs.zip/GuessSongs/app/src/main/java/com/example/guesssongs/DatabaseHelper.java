package com.example.guesssongs;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "users.db";
    private static final int DATABASE_VERSION = 2;
    // Users Table
    private static final String TABLE_USERS = "users";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";
    // Scores Table
    private static final String TABLE_SCORES = "scores";
    private static final String COLUMN_USER_ID = "user_id";
    private static final String COLUMN_SCORE = "score";

    private static final String TABLE_CREATE_USERS =
            "CREATE TABLE " + TABLE_USERS + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_USERNAME + " TEXT, " +
                    COLUMN_PASSWORD + " TEXT" + ");";
    private static final String TABLE_CREATE_SCORES =
            "CREATE TABLE " + TABLE_SCORES + " (" +
                    COLUMN_USER_ID + " INTEGER, " +
                    COLUMN_SCORE + " INTEGER, " +
                    "completion_time TEXT, " + // Add completion_time column
                    "score_rate REAL, " +    // Add score_rate column
                    "FOREIGN KEY(" + COLUMN_USER_ID + ") REFERENCES " + TABLE_USERS + "(" + COLUMN_ID + ")" + ");";
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE_USERS);
        db.execSQL(TABLE_CREATE_SCORES);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SCORES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
    public void addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, password);
        db.insert(TABLE_USERS, null, values);
        db.close();
    }
    public boolean isUserExists(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_USERNAME};
        String selection = COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";
        String[] selectionArgs = {username, password};

        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        boolean exists = (cursor.getCount() > 0);
        cursor.close();
        db.close();
        return exists;
    }

    public void addScore(int userId, int score) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_USER_ID, userId);
        values.put(COLUMN_SCORE, score);
        db.insert(TABLE_SCORES, null, values);
        db.close();
    }
    @SuppressLint("Range")
    public int getHighestScore(int userId) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_SCORE};
        String selection = COLUMN_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        Cursor cursor = db.query(TABLE_SCORES, columns, selection, selectionArgs, null, null, COLUMN_SCORE + " DESC", "1");
        int highestScore = 0;
        if (cursor != null && cursor.moveToFirst()) {
            highestScore = cursor.getInt(cursor.getColumnIndex(COLUMN_SCORE));
        }

        cursor.close();
        db.close();
        return highestScore;
    }
    @SuppressLint("Range")
    public List<ScoreEntry> getAllScores(int userId) {
        List<ScoreEntry> scoreEntries = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {COLUMN_SCORE, "completion_time", "score_rate"}; // Adjust these column names accordingly
        String selection = COLUMN_USER_ID + " = ?";
        String[] selectionArgs = {String.valueOf(userId)};

        // Assuming you have a completion_time and score_rate columns in your scores table
        Cursor cursor = db.query(TABLE_SCORES, columns, selection, selectionArgs, null, null, "completion_time DESC");

        if (cursor != null) {
            while (cursor.moveToNext()) {
                int score = cursor.getInt(cursor.getColumnIndex(COLUMN_SCORE));
                String completionTime = cursor.getString(cursor.getColumnIndex("completion_time")); // Adjust based on your schema
                double scoreRate = cursor.getDouble(cursor.getColumnIndex("score_rate")); // Adjust based on your schema

                scoreEntries.add(new ScoreEntry(score, completionTime, scoreRate));
            }
            cursor.close();
        }
        db.close();
        return scoreEntries;
    }
    public void checkDatabase() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null);
        if (cursor.moveToFirst()) {
            do {
                Log.d("DB_TABLE", cursor.getString(0));
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
    }
}


