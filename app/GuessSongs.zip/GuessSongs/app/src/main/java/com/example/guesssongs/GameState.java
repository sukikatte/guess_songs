package com.example.guesssongs;

import java.util.List;

public class GameState {
    private List<Player> players;
    private int currentQuestionIndex;
    private List<Songs> songs;
    private int correctAnswerCount;
    private boolean isQuestionActive;

    // Getters and setters...
}