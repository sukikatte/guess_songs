package com.example.guesssongs;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import android.media.MediaPlayer;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class GameActivity extends AppCompatActivity {
    private Button optionA, optionB, optionC, optionD, nextButton;
    private TextView timeCountingTextView, questionText, scoreTotal;
    private final Handler handler = new Handler();
    private MediaPlayer mediaPlayer;
    private int seconds = 0;
    private int score = 0;
    private int completedQuestions = 0;
    private int currentQuestion = 1; // 当前题目编号
    private TextView progressText;

    // List of songs
    private final List<Songs> songs = new ArrayList<>();
    private Random random;
    private Songs currentSong;
    private int wrongAttempts; // 记录错误尝试的次数
    private String lastWrongOption = ""; // 记录上一个错误的选项

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_classic);
        // 初始化游戏相关的状态
        completedQuestions = 0;
        score = 0;
        seconds = 0;
        Log.d("GameActivity", "onCreate called");
        findViews();
        startTimer();
        random = new Random();
        // Initialize songs
        initializeSongs();
        // Initialize and play a random song
        loadNextQuestion();
        setupOptionButtons();
        // Set up the Next button
        nextButton.setOnClickListener(v -> loadNextQuestion());
    }

    private void findViews() {
        optionA = findViewById(R.id.optionA);
        optionB = findViewById(R.id.optionB);
        optionC = findViewById(R.id.optionC);
        optionD = findViewById(R.id.optionD);
        nextButton = findViewById(R.id.next_button);
        timeCountingTextView = findViewById(R.id.time_couting);
        questionText = findViewById(R.id.question_text);
        progressText = findViewById(R.id.progress_text);
        scoreTotal = findViewById(R.id.score_total);
    }

    private void initializeSongs() {
        songs.add(new Songs(R.raw.song1, "宝贝", "张悬"));
        songs.add(new Songs(R.raw.song2, "艳火", "张悬"));
        songs.add(new Songs(R.raw.song3, "猎户星座", "朴树"));
        songs.add(new Songs(R.raw.song4, "平凡之路", "朴树"));
        songs.add(new Songs(R.raw.song5, "Mystery of Love", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song6, "Visions of Gideon", "Sufjan Stevens"));
        songs.add(new Songs(R.raw.song7, "The Only Thing", "Sufjan Stevens"));


        // Add more songs here
    }


    @SuppressLint("SetTextI18n")
    private void loadNextQuestion() {
        // Check if 10 questions have been completed
        if (completedQuestions >= 10) {
            navigateToSummary(); // Navigate to summary activity
            return;
        }
        // Reset the timer and prepare for the next question
        seconds = 0;
        timeCountingTextView.setText("time couting: " + seconds + " s");
        handler.removeCallbacksAndMessages(null);
        startTimer();

        currentSong = songs.get(random.nextInt(songs.size()));
        playSong(currentSong.getResourceId());

        boolean askForTitle = random.nextBoolean();
        if (askForTitle) {
            questionText.setText("What is the title of this song?");
            replaceRandomOption(currentSong.getTitle());
        } else {
            questionText.setText("What is the singer of this song?");
            replaceRandomOption(currentSong.getSinger());
        }

        wrongAttempts = 0;
        lastWrongOption = "";
    }



    private void replaceRandomOption(String correctAnswer) {
        // Randomly select one of the options to replace with the correct answer
        Button[] options = {optionA, optionB, optionC, optionD};
        int randomIndex = random.nextInt(options.length);

        // Replace the selected option with the correct answer
        options[randomIndex].setText(correctAnswer);

        // Create a temporary list to store wrong options
        List<String> wrongOptions = new ArrayList<>();

        // Populate the wrongOptions list with other song titles and artists
        for (Songs song : songs) {
            // Avoid adding the correct answer
            if (!song.getTitle().equals(correctAnswer) && !song.getSinger().equals(correctAnswer)) {
                wrongOptions.add(song.getTitle());
                wrongOptions.add(song.getSinger());
            }
        }

        // Shuffle the wrong options to randomize selection
        Collections.shuffle(wrongOptions);

        // Set other options as wrong answers (up to 3 options)
        for (int i = 0; i < options.length; i++) {
            if (i != randomIndex) {
                if (wrongOptions.isEmpty()) {
                    options[i].setText("选项 " + (char) ('A' + i)); // Fallback if no options are left
                } else {
                    // Select a random wrong option
                    options[i].setText(wrongOptions.remove(0)); // Remove to avoid duplicates
                }
            }
        }
    }


    private void playSong(int songResId) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(this, songResId);
        mediaPlayer.start(); // Start playing the audio
    }

    @SuppressLint("SetTextI18n")
    private void startTimer() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                seconds++;
                timeCountingTextView.setText("time counting: " + seconds + " s");
                handler.postDelayed(this, 1000); // 每隔一秒更新一次
            }
        }, 1000);
    }

    private void setupOptionButtons() {
        optionA.setOnClickListener(v -> checkAnswer(optionA.getText().toString()));
        optionB.setOnClickListener(v -> checkAnswer(optionB.getText().toString()));
        optionC.setOnClickListener(v -> checkAnswer(optionC.getText().toString()));
        optionD.setOnClickListener(v -> checkAnswer(optionD.getText().toString()));
    }
    private void checkAnswer(String selectedAnswer) {
        // Determine the correct answer
        boolean isTitleQuestion = questionText.getText().toString().contains("title");
        String correctAnswer = isTitleQuestion ? currentSong.getTitle() : currentSong.getSinger();

        // Check if the selected answer is correct
        if (selectedAnswer.equals(correctAnswer)) {
            completedQuestions++;
            Log.d("GameActivity", "Completed Questions: " + completedQuestions);

            if (seconds < 2) {
                score += 2; // Add bonus points
                Toast.makeText(GameActivity.this, "Perfect! Plus two more points!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(GameActivity.this, "You are Correct!", Toast.LENGTH_SHORT).show();
            }

            // Update score based on wrong attempts
            score += 10 - (wrongAttempts * 2);
            wrongAttempts = 0; // Reset wrong attempts count
            updateScoreDisplay(); // Update score display

            // If this is the 10th question, go to the summary screen instead of the next question
            if (currentQuestion == 10) {
                navigateToSummary();
            } else {
                // Load the next question automatically
                handler.postDelayed(this::loadNextQuestion, 1000);
                currentQuestion++; // Increment the question number first
                updateProgress();  // Update progress after incrementing the question count
            }
        } else {
            // If the user selects the same wrong option, don't deduct the score again
            if (!selectedAnswer.equals(lastWrongOption)) {
                Toast.makeText(GameActivity.this, "The answer is incorrect", Toast.LENGTH_SHORT).show();
                wrongAttempts++; // Record this as a wrong attempt
                score -= 2; // Deduct points for wrong attempt
                updateScoreDisplay(); // Update score display

                // Update lastWrongOption to the current selected answer
                lastWrongOption = selectedAnswer;

                // Only display the message once, do not change question
            } else {
                // If the same wrong option is selected again, show a brief message
                Toast.makeText(GameActivity.this, "You've already selected this option, try another one", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void navigateToSummary() {
        ScoreManager scoreManager = new ScoreManager(this);
        int bestScore = scoreManager.getBestScore();

        if (score > bestScore) {
            scoreManager.saveBestScore(score);
        }
        Intent intent = new Intent(GameActivity.this, SummaryActivity.class);
        intent.putExtra("total_score", score); // Pass the total score to the summary activity
        startActivity(intent);
        finish();// Optional: Finish the current activity
    }


    private void updateScoreDisplay() {
        scoreTotal.setText("totalscore: " + score); // 更新总分的显示
    }
    // 更新进度条和进度文本
    private void updateProgress() {
        progressText.setText(currentQuestion + "/" + "10");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
        if (mediaPlayer != null) {
            mediaPlayer.release(); // Release MediaPlayer resources
            mediaPlayer = null;
        }
    }
}




