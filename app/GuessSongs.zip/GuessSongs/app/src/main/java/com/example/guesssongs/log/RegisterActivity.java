package com.example.guesssongs.log;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RegisterActivity extends AppCompatActivity {
    private EditText mEtUsername, mEtPassword;
    private Button mBtnRegister, returnL;;
    private FirebaseDatabase mDatabase;
    private DatabaseReference mDatabaseRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        findViews();

        mEtUsername = findViewById(R.id.username);
        mEtPassword = findViewById(R.id.password);
        mBtnRegister = findViewById(R.id.newUser);
        returnL = findViewById(R.id.BacktoMain);

        // Initialize Firebase Realtime Database
        mDatabase = FirebaseDatabase.getInstance();
        mDatabaseRef = mDatabase.getReference("user");  // User data will be saved under "users"

        Log.d("Firebase", "Firebase connected: " + (mDatabase != null));
        returnL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 返回到登录活动
                finish(); // 或者可以使用 Intent
            }
        });
        mBtnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("RegisterActivity", "Register button clicked");
                String username = mEtUsername.getText().toString();
                String password = mEtPassword.getText().toString();
                if (!username.isEmpty() && !password.isEmpty()) {
                    User newUser = new User(username, password);

                    mDatabaseRef.push().setValue(newUser)
                            .addOnCompleteListener(task -> {
                                if (task.isSuccessful()) {
                                    Toast.makeText(RegisterActivity.this, "Registration successful", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(RegisterActivity.this, "Registration failed", Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    Toast.makeText(RegisterActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    private void findViews() {
        mBtnRegister = findViewById(R.id.newUser);
        returnL = findViewById(R.id.BacktoMain); // 确保您在布局文件中有这个按钮
        mEtUsername = findViewById(R.id.username);
        mEtPassword = findViewById(R.id.password);
    }
}


/*public class RegisterActivity extends AppCompatActivity {

    private Button confirm,returnL;
    private EditText username, password;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register); //使用注册活动的布局文件
        dbHelper = new DatabaseHelper(this);
        findViews();

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        confirm = findViewById(R.id.newUser);
        returnL = findViewById(R.id.BacktoMain);

        returnL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 返回到登录活动
                finish(); // 或者可以使用 Intent
            }
        });
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();

                if (!user.isEmpty() && !pass.isEmpty()) {
                    dbHelper.addUser(user, pass);
                    Toast.makeText(RegisterActivity.this, "User registered successfully!", Toast.LENGTH_SHORT).show();
                    finish();// 调整到其他活动或清空输入框
                } else {
                    Toast.makeText(RegisterActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void findViews() {
        confirm = findViewById(R.id.newUser);
        returnL = findViewById(R.id.BacktoMain); // 确保您在布局文件中有这个按钮
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
    }
}

 */




