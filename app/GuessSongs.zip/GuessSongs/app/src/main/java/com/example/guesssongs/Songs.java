package com.example.guesssongs;
public class Songs {
    private final int mediaId;
    private final String title;
    private final String singer;

    public Songs(int mediaId, String title, String singer) {
        this.mediaId = mediaId;
        this.title = title;
        this.singer = singer;
    }

    public int getResourceId() {
        return mediaId;
    }

    public String getTitle() {
        return title;
    }

    public String getSinger() {
        return singer;
    }
}