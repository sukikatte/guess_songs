package com.example.guesssongs;

import android.content.Context;
import android.content.SharedPreferences;

public class ScoreManager {
    private SharedPreferences preferences;
    private static final String PREF_NAME = "score_prefs";
    private static final String BEST_SCORE_KEY = "best_score";

    public ScoreManager(Context context) {
        preferences = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void saveBestScore(int score) {
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(BEST_SCORE_KEY, score);
        editor.apply(); // 提交更改
    }

    public int getBestScore() {
        return preferences.getInt(BEST_SCORE_KEY, 0); // 默认值为 0
    }
}