package com.example.guesssongs;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class SummaryActivity extends AppCompatActivity {

    private TextView GametotalScore;
    private Button returnMain, returnGame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);
        findViews();
        GametotalScore = findViewById(R.id.game_total_score);
        int totalScore = getIntent().getIntExtra("total_score", 0);
        GametotalScore.setText("Total Score: " + totalScore);
        returnMain.setOnClickListener(v -> {
            Intent intent = new Intent(SummaryActivity.this, MainActivity.class);
            startActivity(intent);
        });
        returnGame.setOnClickListener(v -> {
            Intent intent = new Intent(SummaryActivity.this, GameActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
            finish(); // Optional: Finish SummaryActivity so it doesn't remain in the back stack
        });

    }
    private void findViews() {
        returnMain = findViewById(R.id.returntoMain);
        GametotalScore = findViewById(R.id.game_total_score);
        returnGame = findViewById(R.id.returntoGame);
    }
}

