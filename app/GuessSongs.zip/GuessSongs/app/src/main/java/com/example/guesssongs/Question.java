package com.example.guesssongs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Question {
    private String questionText; // 存储问题文本
    private String correctAnswer; // 存储正确答案
    private List<String> options; // 存储所有选项

    public Question(String questionText, String correctAnswer, String... options) {
        this.questionText = questionText;
        this.correctAnswer = correctAnswer;
        this.options = new ArrayList<>();

        // 将选项添加到列表，并确保包括正确答案
        Collections.addAll(this.options, options);

        // 确保答案选项中包含正确答案
        if (!this.options.contains(correctAnswer)) {
            this.options.add(correctAnswer);
        }
        Collections.shuffle(this.options); // 打乱选项顺序
    }

    public String getQuestion() {
        return questionText; // 获取问题文本
    }

    public List<String> getOptions() {
        return options; // 获取选项列表
    }

    public boolean isCorrectAnswer(String answer) {
        return answer.equals(correctAnswer); // 检查是否为正确答案
    }

    public String getCorrectAnswer() {
        return correctAnswer; // 获取正确答案
    }
}