package com.example.guesssongs.competitiveMode;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.R;
import com.example.guesssongs.log.User;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RoomStateActivity extends AppCompatActivity {

    private EditText etRoomName, etRoomPassword, etNickname; // Added EditText for nickname
    private String nickname;
    private int currentUserId;
    private DatabaseReference roomsRef; // Firebase数据库引用

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room_state);

        etNickname = findViewById(R.id.etNickname); // Initialize the nickname EditText
        etRoomName = findViewById(R.id.etRoomName);
        etRoomPassword = findViewById(R.id.etRoomPassword);
        currentUserId = getCurrentUserId();

        // 获取Firebase数据库引用
        roomsRef = FirebaseDatabase.getInstance().getReference("rooms");

        findViewById(R.id.createRoomButton).setOnClickListener(this::onCreateRoomClick);
        findViewById(R.id.joinRoomButton).setOnClickListener(this::onJoinRoomClick);
    }

    private void onCreateRoomClick(View view) {
        // Get nickname input
        nickname = etNickname.getText().toString().trim();

        String roomName = etRoomName.getText().toString().trim();
        String roomPassword = etRoomPassword.getText().toString();

        // Validate nickname and room inputs
        if (validateInputs(roomName, roomPassword, nickname)) {
            // Check if the room already exists in Firebase
            roomsRef.child(roomName).get().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult().exists()) {
                    showToast("该房间名已被占用，请换一个房间名！");
                } else {
                    // Create room object
                    Room room = new Room(roomName, roomPassword);
                    Log.d("RoomStateActivity", "Creating room: " + roomName + " with password: " + roomPassword);  // Log room details

                    roomsRef.child(roomName).setValue(room).addOnCompleteListener(roomTask -> {
                        if (roomTask.isSuccessful()) {
                            addPlayerToRoom(roomName);
                            navigateToRoomActivity(roomName);
                        } else {
                            showToast("房间创建失败，请重试！");
                        }
                    });
                }
            });
        }
    }

    private void onJoinRoomClick(View view) {
        // Get nickname input
        nickname = etNickname.getText().toString().trim();

        String roomName = etRoomName.getText().toString().trim();
        String roomPassword = etRoomPassword.getText().toString().trim();  // Trim input password

        if (validateInputs(roomName, roomPassword, nickname)) {
            // Validate the room password
            roomsRef.child(roomName).get().addOnCompleteListener(task -> {
                if (task.isSuccessful() && task.getResult().exists()) {
                    Room room = task.getResult().getValue(Room.class);
                    if (room != null) {
                        String storedPassword = room.getRoomPassword(); // Retrieve stored room password
                        Log.d("RoomStateActivity", "Stored password: " + storedPassword);  // Log the stored password
                        Log.d("RoomStateActivity", "Entered password: " + roomPassword);  // Log the entered password

                        if (storedPassword != null && storedPassword.equals(roomPassword)) {
                            if (room.getPlayerCount() < 3) {
                                addPlayerToRoom(roomName);
                                navigateToRoomActivity(roomName);
                            } else {
                                showToast("房间已满，无法加入！");
                            }
                        } else {
                            showToast("房间名或密码错误！");
                        }
                    } else {
                        showToast("房间数据读取失败，请重试！");
                    }
                } else {
                    showToast("房间不存在！");
                }
            });
        }
    }



    private void addPlayerToRoom(String roomName) {
        DatabaseReference roomRef = roomsRef.child(roomName);

        // Create User object and add it to the room
        User currentUser = new User(nickname, "");  // User's password can be handled later

        roomRef.child("players").child(nickname).setValue(currentUser); // Adding user to players

        // Update player count
        roomRef.child("playerCount").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Integer playerCount = task.getResult().getValue(Integer.class);
                if (playerCount != null) {
                    roomRef.child("playerCount").setValue(playerCount + 1);
                } else {
                    roomRef.child("playerCount").setValue(1);
                }
            }
        });
    }

    private void navigateToRoomActivity(String roomName) {
        Intent intent = new Intent(this, RoomActivity.class);
        intent.putExtra("roomName", roomName);
        intent.putExtra("nickname", nickname); // Pass the nickname to RoomActivity
        startActivity(intent);
    }

    private boolean validateInputs(String roomName, String roomPassword, String nickname) {
        if (nickname.isEmpty()) {
            showToast("请填写昵称！");
            return false;
        }
        if (roomName.isEmpty() || roomPassword.isEmpty()) {
            showToast("请填写完整的房间信息！");
            return false;
        }

        if (!roomPassword.matches("\\d{6}")) {
            showToast("密码必须是6位数字！");
            return false;
        }

        return true;
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private int getCurrentUserId() {
        SharedPreferences sharedPreferences = getSharedPreferences("UserSession", Context.MODE_PRIVATE);
        return sharedPreferences.getInt("userId", -1);
    }
}