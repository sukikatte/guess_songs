package com.example.guesssongs.competitiveMode;

import com.example.guesssongs.Player;
import com.example.guesssongs.log.User;

/*public class Room {
    private String roomName;
    private String roomPassword;
    private Player player1;
    private Player player2;
    private Player player3;
    private int playerCount;
    private int currentQuestion;
    private int correctAnswerCount;

    // Firebase needs a no-argument constructor
    public Room() {}

    public Room(String roomName,String roomPassword){
        this.roomName = roomName;
        this.roomPassword = roomPassword;
        this.playerCount = 0;
    }
    public Room(String roomName, String roomPassword, Player player1, Player player2, Player player3, int playerCount, int currentQuestion, int correctAnswerCount) {
        this.roomName = roomName;
        this.roomPassword = roomPassword;
        this.player1 = player1;
        this.player2 = player2;
        this.player3 = player3;
        this.playerCount = playerCount;
        this.currentQuestion = currentQuestion;
        this.correctAnswerCount = correctAnswerCount;
    }

    // Getter and Setter methods for each field
    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public String getRoomPassword() {
        return roomPassword;
    }

    public void setRoomPassword(String roomPassword) {
        this.roomPassword = roomPassword;
    }

    public Player getPlayer1() {
        return player1;
    }

    public void setPlayer1(Player player1) {
        this.player1 = player1;
    }

    public Player getPlayer2() {
        return player2;
    }

    public void setPlayer2(Player player2) {
        this.player2 = player2;
    }

    public Player getPlayer3() {
        return player3;
    }

    public void setPlayer3(Player player3) {
        this.player3 = player3;
    }

    public int getPlayerCount() {
        return playerCount;
    }

    public void setPlayerCount(int playerCount) {
        this.playerCount = playerCount;
    }

    public int getCurrentQuestion() {
        return currentQuestion;
    }

    public void setCurrentQuestion(int currentQuestion) {
        this.currentQuestion = currentQuestion;
    }

    public int getCorrectAnswerCount() {
        return correctAnswerCount;
    }

    public void setCorrectAnswerCount(int correctAnswerCount) {
        this.correctAnswerCount = correctAnswerCount;
    }
}

 */
public class Room {
    private String roomName;
    private int playerCount;
    private String roomPassword; // 添加房间密码字段
    private User player1;
    private User player2;
    private User player3;

    // 无参构造函数
    public Room() {
        // Firebase 需要这个构造函数
    }

    // 其他构造函数
    public Room(String roomName, String roomPassword) {
        this.roomName = roomName;
        this.roomPassword = roomPassword;
        this.playerCount = 0; // 初始化玩家数量
    }

    // Getters 和 Setters
    public String getRoomName() {
        return roomName;
    }

    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }

    public int getPlayerCount() {
        return playerCount;
    }

    public void setPlayerCount(int playerCount) {
        this.playerCount = playerCount;
    }

    public String getRoomPassword() {
        return roomPassword;
    }

    public void setRoomPassword(String roomPassword) {
        this.roomPassword = roomPassword;
    }

    public User getPlayer1() {
        return player1;
    }

    public void setPlayer1(User player1) {
        this.player1 = player1;
    }

    public User getPlayer2() {
        return player2;
    }

    public void setPlayer2(User player2) {
        this.player2 = player2;
    }

    public User getPlayer3() {
        return player3;
    }

    public void setPlayer3(User player3) {
        this.player3 = player3;
    }
}