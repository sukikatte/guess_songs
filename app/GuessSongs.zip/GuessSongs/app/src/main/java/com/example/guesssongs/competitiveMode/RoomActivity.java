package com.example.guesssongs.competitiveMode;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.guesssongs.R;
import com.example.guesssongs.log.User;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RoomActivity extends AppCompatActivity {
    private TextView user1TextView, user2TextView, user3TextView;
    private String roomName;
    private String nickname; // 当前玩家昵称

    private DatabaseReference roomRef; // Firebase 数据库引用

    private Handler handler = new Handler();
    private boolean isGameStarted = false; // 防止游戏开始后跳转多次
    private boolean isCountdownStarted = false; // 防止倒计时 Toast 重复显示
    private Runnable updateTask = new Runnable() {
        @Override
        public void run() {
            updateRoomPlayers();
            handler.postDelayed(this, 2000); // 每2秒更新一次
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);

        user1TextView = findViewById(R.id.user1TextView);
        user2TextView = findViewById(R.id.user2TextView);
        user3TextView = findViewById(R.id.user3TextView);

        roomName = getIntent().getStringExtra("roomName");
        nickname = getIntent().getStringExtra("nickname");

        if (roomName == null || nickname == null) {
            Log.e("RoomActivity", "未接收到房间名称或昵称");
            return;
        }

        Log.d("RoomActivity", "接收到房间名称: " + roomName + ", 当前用户: " + nickname);

        // 设置标题
        setTitle("房间：" + roomName);

        // 获取 Firebase 数据库引用
        roomRef = FirebaseDatabase.getInstance().getReference("rooms").child(roomName);

        // 将当前玩家添加到房间
        addPlayerToRoom();

        // 退出房间按钮
        findViewById(R.id.exitRoomButton).setOnClickListener(this::onExitRoomClick);
    }

    private void addPlayerToRoom() {
        User currentUser = new User(nickname, "");  // 创建当前玩家的 User 对象

        // 获取当前玩家的位置并添加到对应的 player 字段
        roomRef.child("playerCount").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Integer playerCount = task.getResult().getValue(Integer.class);
                if (playerCount == null) {
                    playerCount = 0; // 初始化玩家数量
                }
                switch (playerCount) {
                    case 0:
                        roomRef.child("player1").setValue(currentUser);
                        break;
                    case 1:
                        roomRef.child("player2").setValue(currentUser);
                        break;
                    case 2:
                        roomRef.child("player3").setValue(currentUser);
                        break;
                    default:
                        Toast.makeText(this, "房间已满", Toast.LENGTH_SHORT).show();
                        return; // 房间已满，退出方法
                }
                roomRef.child("playerCount").setValue(playerCount + 1);  // 更新玩家数量
            } else {
                Log.e("RoomActivity", "获取玩家数量失败: " + task.getException());
            }
        });
    }

    private void updateRoomPlayers() {
        roomRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // 获取每个玩家的数据并显示
                User player1 = task.getResult().child("player1").getValue(User.class);
                User player2 = task.getResult().child("player2").getValue(User.class);
                User player3 = task.getResult().child("player3").getValue(User.class);

                // 显示玩家信息
                user1TextView.setText(player1 != null ? "玩家1: " + player1.getUsername() : "等待玩家1加入");
                user2TextView.setText(player2 != null ? "玩家2: " + player2.getUsername() : "等待玩家2加入");
                user3TextView.setText(player3 != null ? "玩家3: " + player3.getUsername() : "等待玩家3加入");

                // 如果房间内有3个玩家，显示提示并启动倒计时
                if (player1 != null && player2 != null && player3 != null) {
                    if (!isGameStarted) {
                        Toast.makeText(RoomActivity.this, "房间人齐了，即将开始游戏", Toast.LENGTH_SHORT).show();
                        startGameCountdown();
                        isGameStarted = true;  // 确保跳转只发生一次
                    }
                }
            }
        });
    }
    private void startGameCountdown() {
        final int countdownTime = 3; // 3秒倒计时
        final int[] countdown = {countdownTime};

        roomRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                // Get player data
                User player1 = task.getResult().child("player1").getValue(User.class);
                User player2 = task.getResult().child("player2").getValue(User.class);
                User player3 = task.getResult().child("player3").getValue(User.class);

                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (countdown[0] > 0) {
                            // Ensure countdown Toast is only shown once
                            if (!isCountdownStarted) {
                                Toast.makeText(RoomActivity.this, "游戏即将开始：" + countdown[0] + "秒", Toast.LENGTH_SHORT).show();
                                isCountdownStarted = true;  // Prevent duplicate Toast
                            }
                            countdown[0]--;
                            handler.postDelayed(this, 1000);
                        } else {
                            // Countdown finished, start CompetitiveActivity
                            Intent intent = new Intent(RoomActivity.this, CompetitiveActivity.class);

                            // Create an array of player nicknames
                            String[] nicknames = new String[]{
                                    player1 != null ? player1.getUsername() : "未知",
                                    player2 != null ? player2.getUsername() : "未知",
                                    player3 != null ? player3.getUsername() : "未知"
                            };

                            // Pass the nicknames to the CompetitiveActivity
                            intent.putExtra("nickname", nicknames);
                            intent.putExtra("roomName", roomName);
                            startActivity(intent);
                            finish();
                        }
                    }
                }, 1000);
            } else {
                Log.e("RoomActivity", "获取房间数据失败: " + task.getException());
            }
        });
    }

    public void onExitRoomClick(View view) {
        roomRef.child("playerCount").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Integer playerCount = task.getResult().getValue(Integer.class);
                if (playerCount != null) {
                    // 根据玩家昵称判断退出的玩家，并移除该玩家的资料
                    if (nickname.equals("player1")) {
                        roomRef.child("player1").removeValue();
                        user1TextView.setText("等待玩家1加入");  // 更新UI
                    } else if (nickname.equals("player2")) {
                        roomRef.child("player2").removeValue();
                        user2TextView.setText("等待玩家2加入");  // 更新UI
                    } else if (nickname.equals("player3")) {
                        roomRef.child("player3").removeValue();
                        user3TextView.setText("等待玩家3加入");  // 更新UI
                    }

                    // 更新玩家数量
                    if (playerCount > 1) {
                        roomRef.child("playerCount").setValue(playerCount - 1);
                    } else {
                        roomRef.removeValue();  // 删除房间
                        Toast.makeText(this, "房间已销毁，房间名可以再次使用！", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        // 返回上一界面
        finish();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // 确保玩家退出房间
        roomRef.child("playerCount").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Integer playerCount = task.getResult().getValue(Integer.class);
                if (playerCount != null) {
                    if (nickname.equals("player1")) {
                        roomRef.child("player1").removeValue();
                    } else if (nickname.equals("player2")) {
                        roomRef.child("player2").removeValue();
                    } else if (nickname.equals("player3")) {
                        roomRef.child("player3").removeValue();
                    }
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(updateTask); // 开始轮询
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(updateTask); // 停止轮询
    }
}
